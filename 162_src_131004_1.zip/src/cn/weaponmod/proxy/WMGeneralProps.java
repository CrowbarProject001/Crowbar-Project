package cn.weaponmod.proxy;

public class WMGeneralProps {

	public static final String NET_CHANNEL_CLIENT = "WM_NET_CLIENT", NET_CHANNEL_SERVER = "WM_NET_SERVER";
	
	public static final byte NET_ID_CLICKING = 0, NET_ID_DM = 1, NET_ID_EXPLOSION = 2;

}
