package cn.weaponmod.proxy;

public class WMCommonProxy {

	public void preInit() {}

	public void init() {}
	
}
