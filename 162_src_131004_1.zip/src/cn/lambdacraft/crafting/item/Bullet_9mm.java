package cn.lambdacraft.crafting.item;

import cn.lambdacraft.core.CBCMod;

public class Bullet_9mm extends ItemBullet {

	public Bullet_9mm(int par1) {
		super(par1);
		setCreativeTab(CBCMod.cctMisc);
		setIAndU("bullet_9mm");
		setMaxStackSize(64);
	}

}
