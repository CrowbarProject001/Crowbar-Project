package cn.lambdacraft.crafting.item;

import cn.lambdacraft.core.item.CBCGenericItem;

public abstract class ItemBullet extends CBCGenericItem {

	public ItemBullet(int par1) {
		super(par1);
	}

}
