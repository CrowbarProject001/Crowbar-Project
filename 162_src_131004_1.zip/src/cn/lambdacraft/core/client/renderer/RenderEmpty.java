package cn.lambdacraft.core.client.renderer;

import net.minecraft.client.renderer.entity.RenderEntity;
import net.minecraft.entity.Entity;

/**
 * 喜闻乐见的空渲染器（Entity）
 */
public class RenderEmpty extends RenderEntity {
	@Override
	public void doRender(Entity par1Entity, double par2, double par4,
			double par6, float par8, float par9) {

	}
}
