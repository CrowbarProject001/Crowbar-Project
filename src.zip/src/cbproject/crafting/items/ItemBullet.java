package cbproject.crafting.items;

import net.minecraft.item.Item;

public abstract class ItemBullet extends Item {

	public ItemBullet(int par1) {
		super(par1);
	}

}
