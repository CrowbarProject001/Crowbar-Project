package cbproject.core.register;

public interface IKeyProcess {
	public void onKeyDown();
	
	public void onKeyUp();
}
