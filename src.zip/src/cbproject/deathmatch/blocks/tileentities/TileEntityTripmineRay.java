package cbproject.deathmatch.blocks.tileentities;

import net.minecraft.tileentity.TileEntity;

public class TileEntityTripmineRay extends TileEntity {

}
