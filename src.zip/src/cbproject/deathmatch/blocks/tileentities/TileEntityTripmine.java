package cbproject.deathmatch.blocks.tileentities;

import net.minecraft.tileentity.TileEntity;

public class TileEntityTripmine extends TileEntity {

	public TileEntityTripmine() {
	}

}
