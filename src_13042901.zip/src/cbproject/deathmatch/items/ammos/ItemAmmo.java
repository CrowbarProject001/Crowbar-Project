package cbproject.deathmatch.items.ammos;

import net.minecraft.item.Item;

public abstract class ItemAmmo extends Item {

	public ItemAmmo(int par1) {
		super(par1);
	}

}
