package cbproject.deathmatch.blocks;

import cbproject.core.CBCMod;
import net.minecraft.block.BlockOreStorage;

public class BlockRefined extends BlockOreStorage {

	public BlockRefined(int par1) {
		super(par1);
		setCreativeTab(CBCMod.cct);
	}

}
