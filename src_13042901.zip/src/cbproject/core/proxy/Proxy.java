package cbproject.core.proxy;

public class Proxy {
	
	public void init() {
	}
}
