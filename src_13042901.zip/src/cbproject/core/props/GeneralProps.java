package cbproject.core.props;

public class GeneralProps {

}
