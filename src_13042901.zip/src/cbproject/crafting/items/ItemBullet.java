package cbproject.crafting.items;

import cbproject.deathmatch.items.ammos.ItemAmmo;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public abstract class ItemBullet extends Item {

	public ItemBullet(int par1) {
		super(par1);
	}

}
