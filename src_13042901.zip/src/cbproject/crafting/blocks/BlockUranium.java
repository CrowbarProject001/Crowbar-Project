package cbproject.crafting.blocks;

import cbproject.core.CBCMod;
import net.minecraft.block.BlockOre;

public class BlockUranium extends BlockOre {

	public BlockUranium(int par1) {
		super(par1);
		setCreativeTab(CBCMod.cct);
	}

}
